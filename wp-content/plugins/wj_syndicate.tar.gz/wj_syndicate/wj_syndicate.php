<?php
/*
Plugin Name: WJ Syndicate
Plugin URI: http://wjaz.pl
Description: Plugin for post syndication to Facebook, Twitter, Google Blogspot, and Wordpress.com
Version: 1.0
Author: Wojciech Jazgara
Author URI: http://wjaz.pl
License: GPLv2
*/

//-------------------------
//PLUGIN ACTIVATION
//-------------------------
register_activation_hook(__FILE__, 'wj_syndicate_install');

function wj_syndicate_install() {
	global $wp_version;

	//checking whether WP version is compatible with plugin
	if(version_compare($wp_version, '4.0', '<')) {
		wp_die('This plugin requires Wordpress version 4.0 or higher.');
	}
}

//-------------------------
//PLUGIN DEACTIVATION
//-------------------------
register_deactivation_hook(__FILE__, 'wj_sydicate_deactivate');

function wj_sydicate_deactivate() {

}

//CHANGING POST TITLES
add_filter('the_title', 'wj_custom_title');

function wj_custom_title($title) {
	$title .= ' - By Wojtek Jazgara';

	return $title;
}

//CHANGING POST CONTENT
add_filter('the_content', 'wj_content_footer');

function wj_content_footer($content) {
	$content .= '<br><h3>Liked the article?</h3><p>Go to <a href="http://wjaz.pl">wjaz.pl</a> for more!</p><br>';

	return $content;
}

//ADDING SOME CUSTOM CSS
add_action('wp_head', 'wj_head_style');

function wj_head_style() {
	?>
	<style>
		h1.entry-title a {
			font-weight: bold;
		}

		h1.entry-title a:hover {
			text-decoration: underline;
		}
	</style>
	<?php
}

//CREATING PLUGIN SETTINGS MENU
add_action('admin_menu', 'wj_add_admin_menu');

function wj_add_admin_menu() {
	//adding top level menu
	add_menu_page('WJ Sydicate Plugin Page', 'WJ Syndicate', 'manage_options', 'wj_main_menu',
		'wj_syndicate_options_page');

	//register settings
	add_action('admin_init', 'wj_register_settings');
}

function wj_register_settings() {
	register_setting('wj-syn-option-group', 'wj_syn_options', 'wj_sanitize_options');
}

//Plugin option page
function wj_syndicate_options_page() {
	wp_enqueue_script('jquery-ui-tabs');
	wp_enqueue_script('wj-settings-script', plugin_dir_url(__FILE__) . 'js/settings_page.js');
	wp_enqueue_style('jquery-theme-style', plugin_dir_url(__FILE__) . 'css/jquery-ui/jquery-ui.css');

	$options = get_option('wj_syn_options');

	?>
	<div id="tabs">
		<ul>
			<li><a href="#tabs-1">First</a></li>
			<li><a href="#tabs-2">Second</a></li>
			<li><a href="#tabs-3">Third</a></li>
		</ul>
		<div id="tabs-1" class="wrap">
			<form action="options.php" method="post">
				<?php settings_fields('wj-syn-option-group'); ?>
				<h3>Minimum length of the message:</h3>
				<input type="text" name="wj_syn_options[option_min_length]"
				      value="<?php echo esc_attr($options['option_min_length']); ?>" />
				<br><br>
				<button type="submit">Save changes</button>
			</form>
		</div>

		<div id="tabs-2">
			Second div
		</div>

		<div id="tabs-3">
			Third div
		</div>
	</div>
	<?php
}

function wj_sanitize_options($input) {
	$input['option_min_length'] = sanitize_text_field($input['option_min_length']);

	return $input;
}